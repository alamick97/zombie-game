// 9504853406CBAC39EE89AA3AD238AA12CA198043

#include "Game.h"
#include <iostream>

int main (int argc, char** argv) {
	// Speeds up project's I/O
	std::ios_base::sync_with_stdio(false);

	Game game(argc, argv); //creates game object on the stack

	//cin.fail (no more rounds) && all zombies dead (active list is empty)
	while () {
		//if dead break out (step 4)
	}

	// Testing==========BEGIN===================================================
	// Testing==========END=====================================================

	return 0;
}
