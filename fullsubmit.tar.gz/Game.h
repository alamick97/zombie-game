// 9504853406CBAC39EE89AA3AD238AA12CA198043

#ifndef GAME_H
#define GAME_H

#include "Zombie.h"

#include <iostream>
#include <getopt.h>
#include <deque>
#include <queue>

//zombie comparator functor (to use for std::priority_queue)
struct ZComparator {
	bool operator<() {
		//TODO: Implement.	
	}
};

class Game {
private:
    //input handling vars
    int _argc;
    char ** _argv; 
    bool _verbose_flag; //temp
    bool _stats_flag; //temp
    bool _median_flag; //temp
    uint32_t _stats_arg;

    //OutputMode _output_mode; //to remove
    //TODO: Implement:
    //          1) Master zombie list! -> Deque?
    //          2) Active list! (Alive) -> PQ?
    //          3) Inactive List (Dead)

    //need 2 other PQ's for Most (1 PQ) & Least (1 PQ) active
    /*when we find that the game has ended, */
public:
    //constructor handles get_opt options in constructor/and-or function
    Game(int argc, char** argv);
        
    
    //utility functions
    Zombie getPQZombie();
    //=====================================================================================
    //TESTING FUNCTIONS START:=====================================================
    //TESTING FUNCTIONS END:=======================================================
    //=====================================================================================
};


#endif // GAME_H