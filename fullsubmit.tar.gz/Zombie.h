// 9504853406CBAC39EE89AA3AD238AA12CA198043

#ifndef ZOMBIE_H
#define ZOMBIE_H

class Zombie {
private:

public:
    Zombie();

};


#endif //ZOMBIE_H