// 9504853406CBAC39EE89AA3AD238AA12CA198043

#ifndef ZCOMP_H
#define ZCOMP_H

#include <iostream>

class ZComp {
private:

public:
    ZComp(); //default constructor
};


#endif //ZCOMP_H